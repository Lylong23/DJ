<template>
    <div class="my-phone">
       <div class="phone">
        <!-- 命名插槽 -->
        <slot name="phone" />
      </div>
    </div>
</template>

<script>
    export default {
        
    }
</script>

<style lang="scss" scoped>

</style>