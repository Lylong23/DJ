<template>
  <div>
    <div class="center">
      <h1>技术参数</h1>
      <div id="fei">
      <h3>飞行器</h3>
      <ul>
        <li>
          <h4>起飞重量</h4>
        </li>
        <li>
          <div>低于 249 克[1]</div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>尺寸（长、宽、高）</h4>
        </li>
        <li>
          <div>
            折叠：长 145 毫米，宽 90 毫米，高 62 毫米<br>
            展开：长 171 毫米，宽 245 毫米，高 62 毫米 <br>
            展开(含桨叶)：长 251 毫米，宽 362 毫米，高 70毫米
          </div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>轴距</h4>
        </li>
        <li>
          <div>247 毫米</div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>最大上升速度</h4>
        </li>
        <li>
          <div>
            5 米/秒（运动挡）<br>
            3 米/秒（普通挡） <br>
            2 米/秒（平稳挡）
          </div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>最大下降速度</h4>
        </li>
        <li>
          <div>
            5 米/秒（运动挡俯冲下降时） <br>
            3 米/秒（普通挡） <br>
            1.5 米/秒（平稳挡）
          </div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>最大水平飞行速度（海平面附近无风情况下）[2]</h4>
        </li>
        <li>
          <div>
            16 米/秒（运动挡） <br>
            10 米/秒（普通挡） <br>
            6 米/秒（平稳挡）
          </div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>最大起飞海拔高度</h4>
        </li>
        <li>
          <div>
            搭载智能飞行电池：4000 米<br>
             搭载长续航智能飞行电池：3000 米[3]
          </div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>最长飞行（前飞）时间</h4>
        </li>
        <li>
          <div>
            34 分钟（智能飞行电池，无风环境 21.6 公里/小时匀速飞行）<br>
            47分钟（长续航智能飞行电池，无风环境 21.6 公里/小时匀速飞行）
          </div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>最长悬停时间</h4>
        </li>
        <li>
          <div>
            30 分钟（智能飞行电池，无风环境） <br>
            40 分钟（长续航智能飞行电池，无风环境）
          </div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>最大续航里程</h4>
        </li>
        <li>
          <div>
            18 公里（智能飞行电池，无风环境 43.2 公里/小时匀速飞行）<br>
             25公里（搭载长续航智能飞行电池，无风环境 43.2 公里/小时匀速飞行）
          </div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>最大抗风速度</h4>
        </li>
        <li>
          <div>10.7 米/秒（5 级风）</div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>最大可倾斜角度</h4>
        </li>
        <li>
          <div>前飞：40°，后飞：35°（运动挡） <br>
            25°（普通挡） <br>
            25°（平稳挡）
          </div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>最大旋转角速度（默认值）</h4>
        </li>
        <li>
          <div>
            默认 130°/秒（运动挡，在 app 内可调节到最大 20°/秒至 250°/秒）<br> 
            默认75°/秒（普通挡，在 app 内可调节到最大 20°/秒至 120°/秒） <br>
            默认30°/秒（平稳挡，在 app 内可调节到最大 20°/秒至 60°/秒）
          </div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>工作环境温度</h4>
        </li>
        <li>
          <div>-10℃ 至 40℃</div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>卫星导航系统</h4>
        </li>
        <li>
          <div>GPS + Galileo + BeiDou</div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>工作频段</h4>
        </li>
        <li>
          <div>2.400-2.4835 GHz <br>
            5.725-5.850 GHz[4]</div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>发射功率（EIRP）</h4>
        </li>
        <li>
          <div>
            2.4 GHz：＜26 dBm（FCC），＜20 dBm（CE/SRRC/MIC）<br>
             5.8 GHz：＜26dBm（FCC/SRRC），＜14 dBm（CE）
          </div>
        </li>
      </ul>

      <ul>
        <li>
          <h4>悬停精度</h4>
        </li>
        <li>
          <div>
            垂直： <br>
            ±0.1 米（视觉定位正常工作时） <br>
            ±0.5 米（GNSS 正常工作时）<br>
            <br>
            水平： <br>
            ±0.3 米（视觉定位正常工作时） <br>
            ±0.5米（高精度定位系统正常工作时）
          </div>
        </li>
      </ul>
      </div>

      <div id="fei">
        <h3>感知系统</h3>
        <ul>
          <li>
            <h4>前视</h4>
          </li>
          <li>
            <div>
              精确测距范围：0.39 至 25 米<br>
              有效避障速度：飞行速度小于 10 米/秒<br>
              视角范围（FOV）：水平 106°，垂直 90°
            </div>
          </li>
        </ul>

        <ul>
          <li>
            <h4>后视</h4>
          </li>
          <li>
            <div>
              精确测距范围：0.36 至 23.4 米<br>
              有效避障速度：飞行速度小于 10 米/秒<br>
              视角范围（FOV）：水平 58°，垂直 73°
            </div>
          </li>
        </ul>

        <ul>
          <li>
            <h4>下视定位</h4>
          </li>
          <li>
            <div>
              精确测距范围：0.15 至 9 米<br>
              精确悬停范围：0.5 至 12 米<br>
              视觉悬停范围：0.5 至 30 米<br>
              有效避障速度：飞行速度小于 3 米/秒<br>
              视角范围（FOV）：前后 104.8°，左右 87.6°
            </div>
          </li>
        </ul>

        <ul>
          <li>
            <h4>下视补光灯</h4>
          </li>
          <li>
            <div>无</div>
          </li>
        </ul>

        <ul>
          <li>
            <h4>有效使用环境</h4>
          </li>
          <li>
            <div>
              表面为漫反射材质，表面纹理丰富，反射率大于 20%（如水泥路面等）
              光照条件充足（大于 15 lux，室内日光灯正常照射环境）</div>
          </li>
        </ul>
      </div>

      <div id="fei">
        <h3>云台</h3>
        <ul>
            <li>
              <h4>结构设计范围</h4>
            </li>
            <li>
              <div>
                俯仰：-135° 至 80°<br>
                横滚：-135° 至 45°<br>
                平移：-30° 至 30°
              </div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>可控转动范围</h4>
            </li>
            <li>
              <div>
                俯仰：-90° 至 60°<br>
                横滚：-90° 或 0°</div>
            </li>
        </ul>
        <ul>
            <li>
              <h4>稳定系统</h4>
            </li>
            <li>
              <div>3 轴机械云台（俯仰、横滚、平移）</div>
            </li>
        </ul>
        <ul>
            <li>
              <h4>最大控制转速（俯仰）</h4>
            </li>
            <li>
              <div>
                100°/秒
              </div>
            </li>
        </ul>
        <ul>
            <li>
              <h4>角度抖动量</h4>
            </li>
            <li>
              <div>±0.01°</div>
            </li>
        </ul>

      </div>

      <div id="fei">
        <h3>相机</h3>
        <ul>
            <li>
              <h4>影像传感器</h4>
            </li>
            <li>
              <div>1/1.3 英寸影像传感器<br>
                最高 4800 万有效像素</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>镜头</h4>
            </li>
            <li>
              <div>
                视角：82.1°<br>
                等效焦距：24 mm <br>
                光圈：f/1.7  <br>
                焦点范围：1 米至无穷远</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>ISO 范围</h4>
            </li>
            <li>
              <div>视频：100 至 6400（自动），100 至 6400（手动）<br>
                照片：100 至 6400（自动），100 至 6400（手动）</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>快门速度</h4>
            </li>
            <li>
              <div>电子快门：2 至 1/8000 秒</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>最大照片尺寸</h4>
            </li>
            <li>
              <div>4:3 宽高比：8064×6048（4800 万像素），4032x3024（1200 万像素）<br>
                16:9 宽高比：4032x2268（1200 万像素）</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>照片拍摄模式</h4>
            </li>
            <li>
              <div>单张拍摄<br>
                    <br>
                    定时拍摄：<br>
                    JPEG：2/3/5/7/10/15/20/30/60 秒<br>
                    JPEG+RAW：2/3/5/7/10/15/20/30/60 秒<br>
                    <br>
                    自动包围曝光（AEB）：3/5 张 @2/3 EV 步长 <br>
                   
                    <br>
                    全景拍摄模式：球形、180°、广角、竖拍</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>图片格式</h4>
            </li>
            <li>
              <div>JPEG/DNG（RAW）</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>录像分辨率</h4>
            </li>
            <li>
              <div>4K：3840×2160@24/25/30/48/50/60fps <br>
                  2.7K：2720×1530@24/25/30/48/50/60fps <br>
                  FHD：1920×1080@24/25/30/48/50/60fps  <br>
                  慢动作拍摄：1920×1080@120fps</div>
            </li>
        </ul>


        <ul>
            <li>
              <h4>视频格式</h4>
            </li>
            <li>
              <div>MP4/MOV（H.264/H.265）</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>视频最大码率</h4>
            </li>
            <li>
              <div>150Mbps</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>数码变焦范围</h4>
            </li>
            <li>
              <div>4K：2 倍<br>
                  2.7K：3 倍<br>
                  FHD：4 倍</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>一键短片模式</h4>
            </li>
            <li>
              <div>渐远、螺旋、冲天、环绕、彗星、小行星</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>色彩模式</h4>
            </li>
            <li>
              <div>Normal <br>
                D-Cinelike</div>
            </li>
        </ul>


        <ul>
            <li>
              <h4>支持文件系统</h4>
            </li>
            <li>
              <div>FAT32（≤32GB）<br>
                exFAT（>32GB）</div>
              </li>
        </ul>


        <ul>
            <li>
              <h4>HDR 模式</h4>
            </li>
            <li>
              <div>拍照模式：单拍模式支持输出 HDR 影像<br>
                  录像模式：使用 24/25/30fps 帧率录像支持输出 HDR 影像</div>
            </li>
        </ul>
        
      </div>

      <div id="fei">
        <h3>图传</h3>
        <ul>
            <li>
              <h4>图传方案</h4>
            </li>
            <li>
              <div>DJI O3</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>实时图传质量</h4>
            </li>
            <li>
              <div>1080p/30fps</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>工作频段</h4>
            </li>
            <li>
              <div>2.400-2.4835 GHz <br>
                5.725-5.850 GHz</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>发射功率（EIRP）</h4>
            </li>
            <li>
              <div>2.4 GHz：＜26 dBm（FCC），＜20 dBm（CE/SRRC/MIC）<br>
                5.8 GHz：＜26 dBm（FCC/SRRC），＜14 dBm（CE）</div>
              </li>
        </ul>

        <ul>
            <li>
              <h4>通信带宽</h4>
            </li>
            <li>
              <div>1.4 MHz、3 MHz、10 MHz、20 MHz、40 MHz</div>
              </li>
        </ul>

        <ul>
            <li>
              <h4>延时（视乎实际拍摄环境及移动设备）</h4>
            </li>
            <li>
              <div>延时（视乎实际拍摄环境及移动设备）</div>
              </li>
        </ul>

        <ul>
            <li>
              <h4>实时图传最大码率</h4>
            </li>
            <li>
              <div>飞行器 + 遥控器：18Mbps</div>
              </li>
        </ul>

        <ul>
            <li>
              <h4>最大下载速率[5]</h4>
            </li>
            <li>
              <div>DJI O3：<br>
                    DJI RC-N1 遥控器：5.5MB/s，DJI RC 带屏遥控器：5.5MB/s <br>
                    <br>
                    Wi-Fi 5：最大 25MB/s</div>
              </li>
        </ul>

        <ul>
            <li>
              <h4>FCC 标准下，常见飞行环境的信号有效距离[6]</h4>
            </li>
            <li>
              <div>强干扰（都市中心）：约 1.5 至 3 公里<br>
                  中干扰（城郊县城）：约 3 至 7 公里<br>
                  无干扰（远郊/海边）：约 7 至 12 公里</div>
              </li>
        </ul>

        <ul>
            <li>
              <h4>天线</h4>
            </li>
            <li>
              <div>4 天线，一发二收</div>
              </li>
        </ul>

        <ul>
            <li>
              <h4>音频传输</h4>
            </li>
            <li>
              <div>无</div>
              </li>
        </ul>
      </div>

      <div id="fei">
        <h3>Wi-Fi</h3>
        <ul>
            <li>
              <h4>协议</h4>
            </li>
            <li>
              <div>802.11 a/b/g/n/ac</div>
            </li>
        </ul>
        <ul>
            <li>
              <h4>工作频段和发射功率（EIRP）</h4>
            </li>
            <li>
              <div>2.400-2.4835 GHz：＜19 dBm（FCC/CE/SRRC/MIC）<br>
                5.725-5.850 GHz：＜20 dBm（FCC/SRRC），＜14 dBm（CE）</div>
            </li>
        </ul>
      </div>

      <div id="fei">
        <h3>蓝牙</h3>
        <ul>
            <li>
              <h4>协议</h4>
            </li>
            <li>
              <div>蓝牙 5.2</div>
            </li>
        </ul>
        <ul>
            <li>
              <h4>工作频段和发射功率（EIRP）</h4>
            </li>
            <li>
              <div>2.400-2.4835 GHz：＜8 dBm</div>
            </li>
        </ul>
      </div>

      <div id="fei">
        <h3>蓝牙</h3>
        <ul>
            <li>
              <h4>协议</h4>
            </li>
            <li>
              <div>蓝牙 5.2</div>
            </li>
        </ul>
        <ul>
            <li>
              <h4>工作频段和发射功率（EIRP）</h4>
            </li>
            <li>
              <div>2.400-2.4835 GHz：＜8 dBm</div>
            </li>
        </ul>
      </div>

      <div id="fei">
        <h3>智能飞行电池</h3>
        <ul>
            <li>
              <h4>容量</h4>
            </li>
            <li>
              <div>2453 毫安时</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>重量</h4>
            </li>
            <li>
              <div>约 80.5 克</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>标称电压</h4>
            </li>
            <li>
              <div>7.38 伏</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>充电限制电压</h4>
            </li>
            <li>
              <div>8.5 伏</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>电池类型</h4>
            </li>
            <li>
              <div>Li-ion</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>能量</h4>
            </li>
            <li>
              <div>18.1 瓦时</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>充电耗时</h4>
            </li>
            <li>
              <div>64 分钟（使用 DJI 30W USB-C 充电器，通过无人机机身充电）<br>
            56 分钟（使用 DJI 30W USB-C 充电器，通过 DJI Mini 3 Pro 双向充电管家充电）</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>充电环境温度</h4>
            </li>
            <li>
              <div>5℃ 至 40℃</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>推荐充电器</h4>
            </li>
            <li>
              <div>DJI 30W USB-C 充电器或其他支持 USB PD 快充协议的充电器（30 瓦）*<br>
*通过无人机机身充电或使用 DJI Mini 3 Pro 双向充电管家充电，支持最大功率为 30 瓦。</div>
            </li>
        </ul>
      </div>

      <div id="fei">
        <h3>长续航智能飞行电池</h3>
        <ul>
            <li>
              <h4>容量</h4>
            </li>
            <li>
              <div>3850 毫安时</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>重量</h4>
            </li>
            <li>
              <div>约 121 克</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>标称电压</h4>
            </li>
            <li>
              <div>7.38 伏</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>充电限制电压</h4>
            </li>
            <li>
              <div>8.5 伏</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>电池类型</h4>
            </li>
            <li>
              <div>Li-ion</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>能量</h4>
            </li>
            <li>
              <div>28.4 瓦时</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>充电耗时</h4>
            </li>
            <li>
              <div>101 分钟（使用 DJI 30W USB-C 充电器，通过无人机机身充电）<br>
78 分钟（使用 DJI 30W USB-C 充电器，通过 DJI Mini 3 Pro 双向充电管家充电）</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>充电环境温度</h4>
            </li>
            <li>
              <div>5℃ 至 40℃</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>推荐充电器</h4>
            </li>
            <li>
              <div>DJI 30W USB-C 充电器或其他支持 USB PD 快充协议的充电器（30 瓦）*<br>
*通过无人机机身充电或使用 DJI Mini 3 Pro 双向充电管家充电，支持最大功率为 30 瓦。</div>
            </li>
        </ul>
      </div>

      <div id="fei">
        <h3>存储卡</h3>
        <ul>
            <li>
              <h4>飞行器支持存储卡类型</h4>
            </li>
            <li>
              <div>请使用 UHS-I Speed Grade 3 及以上的储存卡，或使用推荐列表中的储存卡。</div>
            </li>
        </ul>
        
        <ul>
            <li>
              <h4>推荐存储卡列表</h4>
            </li>
            <li>
              <div>SanDisk Extreme 64GB V30 A1 microSDXC <br>
                SanDisk Extreme 128GB V30 A2 microSDXC <br>
                SanDisk Extreme 256GB V30 A2 microSDXC<br>
                SanDisk Extreme 512GB V30 A2 microSDXC<br>
                SanDisk Extreme Pro 64GB V30 A2 microSDXC<br>
                SanDisk Extreme Pro 256GB V30 A2 microSDXC<br>
                SanDisk Extreme Pro 400GB V30 A2 microSDXC<br>
                SanDisk High Endurance 64GB V30 microSDXC<br>
                SanDisk High Endurance 256GB V30 microSDXC<br>
                SanDisk Max Endurance 32GB V30 microSDHC<br>
                SanDisk Max Endurance 128GB V30 microSDXC<br>
                SanDisk Max Endurance 256GB V30 microSDXC<br>
                Kingston Canvas Go!Plus 64GB V30 A2 microSDXC<br>
                Kingston Canvas Go!Plus 256GB V30 A2 microSDXC<br>
                Lexar High Endurance 64GB V30 microSDXC<br>
                Lexar High Endurance 128GB V30 microSDXC<br>
                Lexar 667x 64GB V30 A1 microSDXC<br>
                Lexar 633x 256GB V30 A1 microSDXC<br>
                Lexar 1066x 64GB V30 A2 microSDXC<br>
                Lexar 1066x 128GB V30 A2 microSDXC<br>
                Lexar 1066x 256GB V30 A2 microSDXC<br>
                Samsung Pro Plus 128GB V30 A2 microSDXC<br>
                Samsung EVO Plus 512GB microSDXC</div>
            </li>
        </ul>
      </div>
      

      <div id="fei">
        <h3>DJI RC-N1 遥控器</h3>
        <ul>
            <li>
              <h4>工作频段和发射功率（EIRP）</h4>
            </li>
            <li>
              <div>2.400-2.4835 GHz：＜26 dBm（FCC），＜20 dBm（CE/SRRC/MIC）<br>
5.725-5.850 GHz：＜26 dBm（FCC），＜23 dBm（SRRC），＜14 dBm（CE）</div>
            </li>
        </ul>
        
        <ul>
            <li>
              <h4>支持接口类型</h4>
            </li>
            <li>
              <div>Lightning、Micro-USB（Type-B）、USB-C</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>图传方案</h4>
            </li>
            <li>
              <div>DJI O3</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>最长续航时间</h4>
            </li>
            <li>
              <div>6 小时（未给移动设备充电）<br>
                4 小时（为移动设备充电）</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>工作环境温度</h4>
            </li>
            <li>
              <div>-10℃ 至 40℃</div>
            </li>
        </ul>

      </div>
      
      <div id="fei">
        <h3>DJI RC</h3>
        <ul>
            <li>
              <h4>遥控器型号</h4>
            </li>
            <li>
              <div>RM330</div>
            </li>
        </ul>
        
        <ul>
            <li>
              <h4>图传方案</h4>
            </li>
            <li>
              <div>DJI O3</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>工作频段和发射功率（EIRP）</h4>
            </li>
            <li>
              <div>2.400-2.4835 GHz：＜26 dBm（FCC），＜20 dBm（CE/SRRC/MIC）<br>
5.725-5.850 GHz：＜26 dBm（FCC），＜23 dBm（SRRC），＜14 dBm（CE）</div>
            </li>
        </ul>

         <ul>
            <li>
              <h4>存储空间</h4>
            </li>
            <li>
              <div>支持使用 microSD 卡拓展存储容量，将所需文件及拍摄图像保存至 microSD 卡后可导入电脑等其他设备。</div>
            </li>
        </ul>
        
        <ul>
            <li>
              <h4>视频输出接口</h4>
            </li>
            <li>
              <div>无</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>最长续航时间</h4>
            </li>
            <li>
              <div>约 4 小时</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>工作环境温度</h4>
            </li>
            <li>
              <div>-10℃ 至 40℃</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>支持存储卡类型</h4>
            </li>
            <li>
              <div>请使用 UHS-I Speed Grade 3 及以上的储存卡，或使用推荐列表中的储存卡。</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>推荐存储卡列表</h4>
            </li>
            <li>
              <div>SanDisk Extreme 64GB V30 A1 microSDXC <br>
                  SanDisk Extreme 128GB V30 A2 microSDXC <br>
                  SanDisk Extreme 256GB V30 A2 microSDXC <br>
                  SanDisk Extreme 512GB V30 A2 microSDXC <br>
                  SanDisk Extreme Pro 64GB V30 A2 microSDXC <br>
                  SanDisk Extreme Pro 256GB V30 A2 microSDXC <br>
                  SanDisk Extreme Pro 400GB V30 A2 microSDXC <br>
                  SanDisk High Endurance 64GB V30 microSDXC <br>
                  SanDisk High Endurance 256GB V30 microSDXC <br>
                  Kingston Canvas Go!Plus 64GB V30 A2 microSDXC <br>
                  Kingston Canvas Go!Plus 256GB V30 A2 microSDXC <br>
                  Lexar High Endurance 64GB V30 microSDXC <br>
                  Lexar High Endurance 128GB V30 microSDXC <br>
                  Lexar 633x 256GB V30 A1 microSDXC <br>
                  Lexar 1066x 64GB V30 A2 microSDXC <br>
                  Samsung EVO Plus 512GB microSDXC</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>Wi-Fi 工作频段和发射功率（EIRP）</h4>
            </li>
            <li>
              <div>2.400-2.4835 GHz：＜23 dBm（FCC），＜20 dBm（CE/SRRC/MIC）<br>
                5.150-5.250 GHz：＜23 dBm（FCC/CE/SRRC/MIC） <br>
                5.725-5.850 GHz：＜23 dBm（FCC/SRRC），＜14 dBm（CE）</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>蓝牙协议</h4>
            </li>
            <li>
              <div>蓝牙 4.2</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>蓝牙工作频段和发射功率（EIRP）</h4>
            </li>
            <li>
              <div>2.400-2.4835 GHz：＜10 dBm</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>Wi-Fi 协议</h4>
            </li>
            <li>
              <div>802.11 a/b/g/n</div>
            </li>
        </ul>
      </div>

      <div id="fei">
        <h3>充电管家</h3>
        <ul>
            <li>
              <h4>适用的 DJI 充电器</h4>
            </li>
            <li>
              <div>DJI 30W USB-C 充电器或其他支持 USB PD 快充协议的充电器（30 瓦）<br>
* 通过无人机机身充电、使用 DJI Mini 3 Pro 双向充电管家充电所支持的最大功率为 30 瓦。</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>适用的 DJI 电池</h4>
            </li>
            <li>
              <div>DJI Mini 3 Pro 智能飞行电池、DJI Mini 3 Pro 长续航智能飞行电池</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>输入</h4>
            </li>
            <li>
              <div>5 伏，3 安<br>
                  9 伏，3 安<br>
                  12 伏，3 安</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>输出（USB）</h4>
            </li>
            <li>
              <div>最大电压 5 伏，最大电流 2 安</div>
            </li>
        </ul>

        <ul>
            <li>
              <h4>充电方式</h4>
            </li>
            <li>
              <div>3 块电池轮充</div>
            </li>
        </ul>
      </div>

      <div id="fei">
        <h3>App</h3>
        <ul>
            <li>
              <h4>移动设备 App</h4>
            </li>
            <li>
              <div>DJI Fly</div>
            </li>
        </ul>
        <ul>
            <li>
              <h4>移动设备系统版本要求</h4>
            </li>
            <li>
              <div>iOS 11.0 或更高版本<br>
                  Android 6.0 或更高版本</div>
            </li>
        </ul>
      </div>

      <div id="fei">
        <h3>其他</h3>
        <ul>
            <li>
              <h4>备注</h4>
            </li>
            <li>
              <div>
                [1] 飞行器标准重量（含 DJI Mini 3 Pro 智能飞行电池、桨叶和 microSD 卡）。产品重量可能会因物料批次不同等原因而有所差异，请以实际产品为准；该产品在部分国家或地区免注册，请查询并确认当地法律法规。以上数据均在最新版固件下测得，请及时关注并保持当前固件为最新版本，以获得最佳性能。 若使用 DJI Mini 3 Pro 长续航智能飞行电池，机身重量会超过 249 克（约 290 克），请在飞行前查询、确认并严格遵守当地法律法规。<br>
[2] 最大水平飞行速度受当地法规动态限制，实际飞行时请遵守当地法律法规。<br>
[3] 飞行器重量增加会影响飞行动力。安装 DJI Mini 3 Pro 长续航智能飞行电池后，请勿安装桨叶保护罩或其他第三方配件等额外负载，以避免动力不足的情况。<br>
[4] 由于当地政策法规限制，在日本、俄罗斯、以色列、乌克兰、哈萨克斯坦等区域激活产品时 5.8 GHz 频段将被自动禁用，在上述地点请使用 2.4 GHz 频段飞行，具体情况请查询并遵守当地法规。<br>
[5] 该数据在支持 2.4 GHz 和 5.8 GHz 双频段的国家或地区的低干扰实验室环境下测得，且素材存储于 SD 卡或机身内置储存空间，实际下载速率请以实际体验为准。<br>
[6] 以上数据采用 FCC 标准，在各种典型干扰强度的场景且无遮挡的环境下测得，不承诺实际飞行距离，仅供用户实际使用时作飞行距离参考。以下为适用各个标准的国家/地区及 DJI Mini 3 Pro 对应的单程不返航飞行的最远通信距离：
FCC 标准：美国、澳大利亚、加拿大、中国香港、中国台湾、智利、哥伦比亚、波多黎各等区域最远通信距离 12 公里。
SRRC 标准：中国大陆地区最远通信距离 8 公里。
CE 标准：英国、俄罗斯、法国、德国、葡萄牙、西班牙、瑞士、中国澳门、新西兰、阿联酋等区域最远通信距离 8 公里。
MIC 标准：日本最远通信距离 8 公里。</div>
            </li>
        </ul>
      </div>

    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
* {
  margin: 0;
  padding: 0;
}
.center{
  width: 1200px;
  margin: 0 auto;
}
h1{
  border-bottom: 1px solid #eee;
  padding: 30px 0;
}
#fei {
  h3{
    padding: 30px 0;
    margin:20px 0;
    font-size: 24px;
  }
  ul:nth-child(2n-1) {
    background: #fff;
  }
  ul {
    display: flex;
    // flex-direction: row;
    padding: 12px 16px;
    background: #f8f9fb;
    vertical-align: baseline;
    list-style: none;
    justify-content: flex-start;

    li {
      padding:20px 30px 20px 0;
      width: 600px;
      display: block;
      
    }
  }
}
</style>