<template>
  <div>
    <div class="far">
      <div class="center">
        <div class="main1">
           <h3>
            轻松飞，放心拍
           </h3>
           <p>
            DJI Mini 3 Pro 超轻型机身采用可折叠设计，收纳便捷，可轻松放进口袋；重量低于 249 克<sup>[1]</sup>，在大部分国家/地区无需注册或培训即可快速起飞。带上它，说走就走，想拍就拍。
           </p>
        </div>
        <div class="main1-pic">
          <img src="/indexImg/1.jpg" alt="">
        </div>
        <div class="main2">
          <div class="main2-top">
            <div>
              <h3>秀出续航硬实力</h3>
            </div>
            <div>
              <p>标配的 DJI Mini 3 Pro 智能飞行电池最长续航可达 34 分钟，足以完成大部分航拍场景拍摄，轻装上阵，轻享创作过程。</p>
            </div>
          </div>
          <div class="main2-medium">
            <img src="/indexImg/2.jpg" alt="">
          </div>
          <div class="main2-footer">
            <p>还有长续航智能飞行电池可供选择，让你飞足 47 分钟<sup>[2]</sup>，拥有充裕的取景和构图空间，去探索广阔天地。告别电量焦虑，飞行更尽兴。</p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  export default {
   
  }
</script>
<style scoped>
  * {
    margin: 0;
    padding: 0;
  }
  .center {
    padding: 128px 128px 0 128px;
    width: 1200px;
    margin: 0 auto; 
  }
  .main1 h3 {
    color:rgba(0,0,0,0.85);
    max-width:693px;
    font-size: 40px;
    line-height: 48px;
  }
  .main1 p {
    color:rgba(0,0,0,0.65);
    max-width:795px;
    font-size: 18px;
    line-height: 28px;
    margin-top: 24px;
    letter-spacing: -.03em;
  }
  .main1-pic img {
    margin-top: 48px;
    border-radius: 16px;
    overflow: hidden;
    display: block;
    width: 100%;
    height: auto;
  }
  .main2 {
    padding-top: 128px;
  }
  .main2-top {
    width: 100%;
    display: flex;
    flex-wrap: nowrap;
    align-items: flex-start;
    padding-bottom: 8px;
  }
  .main2-top h3 {
    color:rgba(0,0,0,0.85);
    max-width:693px;
    font-size: 40px;
    line-height: 48px;
    width: 592px;
  }
  .main2-top p {
    color:rgba(0,0,0,0.65);
    max-width:795px;
    font-size: 18px;
    height: 56px;
    letter-spacing: -.03em;
    margin-left: 16px;
  }
  .main2-medium img {
    margin-bottom: 48px;
    border-radius: 16px;
    overflow: hidden;
    display: block;
    width: 100%;
    height: auto;
  }
  .main2-footer p {
    color: rgba(0, 0, 0, 0.65);
    max-width: 795px;
    font-size: 18px;
    line-height: 28px;
    letter-spacing: -.03em;
  }
</style>
<style lang="scss" scoped>

</style>