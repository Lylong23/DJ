<template>
  <div>
    <!-- 第一部分 -->
    <section class="comments-component comment-dark">
      <div class="container">
        <p class="comment-item">
          * 请在飞行前查询、确认并严格遵守当地法律法规。
        </p>
        <p class="comment-item">
          ** 本页面所列出的各项参数数值，均为量产版 DJI Mini 3 Pro
          飞行器在受控测试环境下测得，在不同的外部环境、使用方式、固件版本下，结果或有不同程度的差异，请以实际体验为准。
        </p>
        <p class="comment-item">
          *** 本页面所有视频和图片均在严格遵守当地相关法律法规的情况下拍摄。
        </p>
        <p class="comment-item">
          **** DJI Mini 3 Pro 须通过 DJI Fly app 激活后使用。
        </p>
        <p class="comment-item">
          [1] 飞行器标准重量（含 DJI Mini 3 Pro 智能飞行电池、桨叶和 microSD
          卡）。产品重量可能会因物料批次不同等原因而有所差异，请以实际产品为准；该产品在部分国家或地区免注册，请查询并确认当地法律法规。
        </p>
        <p class="comment-item">
          [2] 无风环境下，以 21.6 公里/小时匀速飞行时测得。DJI Mini 3 Pro
          智能飞行电池最长续航时间为 34
          分钟；若使用长续航智能飞行电池（该配件需单独购买），最长续航时间为 47
          分钟，且机身重量会超过 249
          克，请在飞行前查询、确认并严格遵守当地法律法规。
        </p>
        <p class="comment-item">[3] 该功能不支持 30fps 以上帧率的录像规格。</p>
        <p class="comment-item">
          [4] 录制
          4K/48fps、4K/50fps、4K/60fps、2.7K/48fps、2.7K/50fps、2.7K/60fps、1080p/120fps
          视频时，APAS 4.0 功能不可用。
        </p>
        <p class="comment-item">[5] FCC 标准，在室外空旷无干扰环境下测得。</p>
        <p class="comment-item">
          [6] 录制
          4K/48fps、4K/50fps、4K/60fps、2.7K/48fps、2.7K/50fps、2.7K/60fps、1080p/48fps、1080p/50fps、1080p/60fps、1080p/120fps
          视频时，焦点跟随功能不可用。
        </p>
        <p class="comment-item">[7] 该配件需单独购买，请以实际发售时间为准。</p>
        <p class="comment-item"></p>
      </div>
      <div class="horizontal-line"></div>
    </section>

    <div class="footer">
      <div class="footer-index">
        <!-- 第二部分 -->
        <div class="footer-category">
          <div class="footer-item">
            <div>
              <p class="index-title">热门产品分类</p>
              <ul class="footer-column">
                <li class="index-nav-item">
                  <a href="#" class="ga-data">消费级</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">专业级</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">行业级</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">系统模块</a>
                </li>
              </ul>
            </div>
            <div>
              <p class="index-title">增值服务</p>
              <ul class="footer-column">
                <li class="index-nav-item">
                  <a href="#" class="ga-data">DJI Care 随心换</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">DJI Care 随心续享</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">DJI Care Pro</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">Osmo Shield</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">DJI Care 行业无忧</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">行业无人机保养服务</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">农机关怀计划</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="footer-item">
            <div>
              <p class="index-title">购买渠道</p>
              <ul class="footer-column">
                <li class="index-nav-item">
                  <a href="#" class="ga-data">官方商城</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">官方旗舰店</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">官方直营店</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">线下门店</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">行业应用购买渠道</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">农业植保机代理商 </a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">专业影像代理商</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">大疆商城 App</a>
                </li>
              </ul>
            </div>
            <div>
              <p class="index-title">企业合作</p>
              <ul class="footer-column">
                <li class="index-nav-item">
                  <a href="#" class="ga-data">成为授权经销商</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="footer-item">
            <div>
              <p class="index-title">安全飞行</p>
              <ul class="footer-column">
                <li class="index-nav-item">
                  <a href="#" class="ga-data">安全飞行指引</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">大疆飞行指南</a>
                </li>
              </ul>
            </div>
            <div>
              <p class="index-title">帮助与支持</p>
              <ul class="footer-column">
                <li class="index-nav-item">
                  <a href="#" class="ga-data">产品支持</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">服务申请与信息支持</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">帮助中心</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">售后服务政策</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">下载中心</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">安全与隐私</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="footer-item">
            <div>
              <p class="index-title">优惠折扣</p>
              <ul class="footer-column">
                <li class="index-nav-item">
                  <a href="#" class="ga-data">以旧换新</a>
                </li>
              </ul>
            </div>
            <div>
              <p class="index-title">探索精彩大疆</p>
              <ul class="footer-column">
                <li class="index-nav-item">
                  <a href="#" class="ga-data">新闻中心</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">精彩活动</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">STEAM教育</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">航拍无人机</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="footer-item">
            <div>
              <p class="index-title">社区</p>
              <ul class="footer-column">
                <li class="index-nav-item">
                  <a href="#" class="ga-data">天空之城</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">大疆社区</a>
                </li>
                <li class="index-nav-item">
                  <a href="#" class="ga-data">开发者</a>
                </li>
              </ul>
            </div>

            <div class="index-subscribe">
              <p class="index-title">订阅我们</p>
              <p class="index-content">第一时间获得大疆的最新动态</p>
              <div id="footer-subscribe" class="form-group">
                <input
                  type="text"
                  placeholder="请输入您的邮箱地址"
                  class="form-input"
                  value=""
                /><button
                  type="button"
                  id="footer-subscribe-btn"
                  data-ga-category="pc-footer"
                  data-ga-action="mouseenter"
                  data-ga-label="other-subscribe"
                  class="index__form-submit___37FVb"
                >
                  <span class="form-submit-icon"></span>
                </button>
                <p class="index-tip"></p>
              </div>
            </div>
          </div>
        </div>

        <!-- 第三部分 -->
        <div class="footer-about">
          <div class="footer-nav">
            <a href="#" class="nav-brand"
              ><img
                class="dps logo index-gray"
                data-dps-src="522803b33c81368bef06e3328ab0225b.svg"
                alt="logo"
                src="https://www1.djicdn.com/dps/522803b33c81368bef06e3328ab0225b.svg"
              />

              <!-- <img class="dps logo index__white___1q2jz"
              data-dps-src="b5706013a451423bba0fa0b307b5ca33.svg"
              alt="logo"
              src="https://www1.djicdn.com/dps/b5706013a451423bba0fa0b307b5ca33.svg"/> -->
            </a>
            <ul class="nav-right">
              <li class="nav-item">
                <a href="#" class="ga-data">关于我们</a>
              </li>
              <li class="nav-item">
                <a href="#" class="ga-data">联系我们</a>
              </li>
              <li class="nav-item">
                <a href="#" class="ga-data">招聘精英</a>
              </li>
              <li class="nav-item">
                <a href="#" class="ga-data">市场合作</a>
              </li>
              <li class="nav-item">
                <a href="#" class="ga-data">代理商门户</a>
              </li>
              <li class="nav-item">
                <a href="#" class="ga-data">供应商门户</a>
              </li>
              <li class="nav-item">
                <a href="#" class="ga-data">RoboMaster</a>
              </li>
              <li class="nav-item">
                <a href="#" class="ga-data">慧飞培训中心</a>
              </li>
              <li class="nav-item">
                <a href="#" class="ga-data">大疆互娱</a>
              </li>
              <li class="nav-item">
                <a href="#" class="ga-data">大疆车载</a>
              </li>
            </ul>
          </div>
          <ul class="footer-social">
            <li class="social-wechat">
              <a href="#" class="ga-data"
                ><img
                  alt="wechat"
                  src="../assets/footer/1.png"
              /></a>
              <div class="popup">
                <div class="er-code">
                  <img
                    class="dps logo"
                    data-dps-src="e25403181910d5e3aa822e4b87b7d580.png"
                    alt="dji"
                    src="../assets/footer/1.webp"
                  />
                </div>
                <div class="triangle"></div>
              </div>
            </li>
            <li class="social-wechat">
              <a href="#" class="ga-data"
                ><img
                  class="img"
                  alt="微博"
                  src="../assets/footer/2.png"
              /></a>
            </li>
            <li class="social-wechat">
              <a href="#" class="ga-data"
                ><img
                  class="img"
                  alt="douyin"
                  src="../assets/footer/3.png"
              /></a>
              <div class="popup">
                <div class="er-code">
                  <img
                    class="dps logo"
                    data-dps-src="85373427fabd814e47a218a4075531e5.jpg"
                    alt="dji"
                    src="../assets/footer/2.webp"
                  />
                </div>
                <div class="triangle"></div>
              </div>
            </li>
            <li class="social-wechat">
              <a href="#" class="ga-data"
                ><img
                  class="img"
                  alt="Bilibili"
                  src="../assets/footer/4.png"
              /></a>
            </li>
            <li class="social-wechat">
              <a href="#" class="ga-data"
                ><img
                  class="img"
                  alt="腾讯视频"
                  src="../assets/footer/5.png"
              /></a>
            </li>
            <li class="social-wechat">
              <a href="#" class="ga-data"
                ><img
                  class="img"
                  alt="头条"
                  src="../assets/footer/6.png"
              /></a>
            </li>
          </ul>
        </div>

        <!-- 第四部分 -->
        <div class="footer-bottom">
          <div class="footer-legal">
            <ul class="legal-links">
              <li class="legal-links">
                <a href="#" class="ga-data">隐私权政策</a>
              </li>
              <li class="legal-links">
                <a href="#" class="ga-data">使用条款</a>
              </li>
              <li class="legal-links">
                <a href="#" class="ga-data">疆湖名录</a>
              </li>
            </ul>
            <div class="footer-feedback">
              <div><i></i></div>
              <a href="#" class="ga-data">网站问题反馈</a>
            </div>
          </div>
        </div>

        <!-- 最后一部分 -->
        <div class="footer-desc">
          <div class="copyright">Copyright © 2022 DJI 大疆创新 版权所有</div>
          <div class="footerdesc-cnF">
            <div id="footer-record">
              <a href="#" class="ga-data ad-descc">粤ICP备12022215号</a>
            </div>
            <p class="ad-desc">
              本网站直接或间接向消费者推销商品或者服务的商业宣传均属于“广告”（包装及参数、售后保障等商品信息除外）
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style lang="scss" scoped>
.comments-component {
  background-color: #272727 !important;
}
.comment-dark {
  padding: 32px 0;
}
.container {
  max-width: 1200px;
  margin: 0 auto;
  margin-top: 64px;
}
.comment-item {
  color: hsla(0, 0%, 100%, 0.65) !important;
  font-size: 12px;
  line-height: 16px;
  letter-spacing: -0.02em;
  margin-bottom: 8px;
}
.horizontal-line {
  width: 1200px;
  margin: 0 auto;
  position: relative;
  height: 48px;
}

.footer {
  background: #272727;
  padding: 72px 0;
  min-width: 1200px;
}
.footer-index {
  width: 1200px;
  margin: 0 auto;
}
.footer-category {
  display: flex;
  flex-wrap: wrap;
  align-items: stretch;
  justify-content: space-between;
}
.footer-item {
  width: 221px;
}
.index-title {
  color: #fff;
  margin-bottom: 8px;
  font-size: 12px;
  line-height: 24px;
  font-weight: 500;
}
.footer-column {
  margin-bottom: 24px;
  list-style: none;
  padding: 0;
}
.index-nav-item {
  margin-bottom: 8px;
  box-sizing: border-box;
}
.index-nav-item a {
  font-size: 12px;
  color: #9fa3a6;
  transition: all 0.3s ease;
  line-height: 24px;
  display: inline-block;
  vertical-align: baseline;
  text-decoration: none;
}
.index-subscribe {
  text-align: left;
}
.index-content {
  font-size: 12px;
  margin-bottom: 16px;
  color: #6c7073;
  line-height: 24px;
}
.form-input {
  display: inline-block;
  font-size: 14px;
  color: #6c7073;
  height: 32px;
  width: 189px;
  background: 0 0;
  outline: none;
  padding: 4px 0 4px 12px;
  border: 1px solid #6c7073;
  border-right: none;
  vertical-align: middle;
  border-radius: 4px 0 0 4px;
  box-sizing: border-box;
}
#footer-subscribe-btn {
  display: inline-block;
  width: 32px;
  height: 32px;
  font-size: 12px;
  line-height: 1;
  color: #fff;
  background: #6c7073;
  border: none;
  outline: none;
  vertical-align: middle;
  border-radius: 0 4px 4px 0;
  transition: all 0.3s ease-in-out;
}
.form-submit-icon {
  width: 16px;
  height: 16px;
  display: inline-block;
  vertical-align: middle;
  background-image: url(data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyIgeG1sbnM6eGxpbms9Imh0dHA6Ly93d3cudzMub3JnLzE5OTkveGxpbmsiPjxkZWZzPjxwYXRoIGQ9Ik0yLjg1NyA2LjE0djUuNDk2YzAgLjI1MS4xOTIuNDU1LjQyOS40NTVoOS40MjhjLjIzNyAwIC40MjktLjIwNC40MjktLjQ1NVY2LjEyNUw4LjY5NiA5LjE3OWMtLjQyMy4yODQtLjk2OS4yODQtMS4zOTIgMGwtNC40NDctMy4wNHpNMy4yODYgM2g5LjQyOEMxMy40MjQgMyAxNCAzLjYxIDE0IDQuMzY0djcuMjcyQzE0IDEyLjM5IDEzLjQyNCAxMyAxMi43MTQgMTNIMy4yODZDMi41NzYgMTMgMiAxMi4zOSAyIDExLjYzNlY0LjM2NEMyIDMuNjEgMi41NzYgMyAzLjI4NiAzem0wIC45MWMtLjIzNyAwLS40MjkuMjAzLS40MjkuNDU0di40NGMwIC4xNTIuMDc0LjI5Ni4yMDEuMzgzbDQuNzE0IDMuMjI1YS4zOTguMzk4IDAgMDAuNDU2IDBsNC43MTQtMy4yMzlhLjQ0OC40NDggMCAwMC4yLS4zODN2LS40MjZjMC0uMjUxLS4xOTEtLjQ1NS0uNDI4LS40NTVIMy4yODZ6IiBpZD0iYSIvPjwvZGVmcz48dXNlIGZpbGw9IiNGRkYiIHhsaW5rOmhyZWY9IiNhIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiLz48L3N2Zz4=);
  background-size: 16px 16px;
  background-repeat: no-repeat;
  background-position: 50%;
}
.footer-about {
  display: flex;
  align-items: flex-end;
  border-bottom: 1px solid #6c7073;
  justify-content: space-between;
  margin-top: 48px;
  padding-bottom: 16px;
  padding: 0;
}
.footer-nav {
  display: flex;
  align-items: flex-end;
  padding-bottom: 16px;
}
.nav-brand {
  display: block;
  width: 42px;
  height: 24px;
  margin-right: 20px;
  background-color: transparent;
}
.site-footer {
  display: flex;
  align-items: center;
}
.nav-right {
  display: flex;
  align-items: center;
  padding: 0;
}
.nav-item {
  display: block;
  padding: 0 12px;
  height: 24px;
}
.ga-data {
  font-size: 12px;
  color: #9fa3a6;
  transition: all 0.3s ease;
  line-height: 24px;
  display: inline-block;
  vertical-align: baseline;
  text-decoration: none;
}
.footer-social {
  display: flex;
  align-items: center;
  height: 24px;
  padding-bottom: 16px;
}
.social-wechat {
  position: relative;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  cursor: pointer;
  transition: all 0.3s;
}
.social-wechat img {
  height: 16px;
  display: block;
}
.popup {
  box-shadow: 0 2px 6px 0 rgba(0, 0, 0, 0.1);
  position: absolute;
  bottom: 26px;
  right: -5px;
  width: 144px;
  height: 160px;
  visibility: hidden;
  opacity: 0;
  transition: visibility 0.3s ease, opacity 0.3s ease;
}
.er-code {
  padding: 4px;
  border-radius: 4px;
  background: #fff;
  box-shadow: 0 2px 6px 0 rgba(0, 0, 0, 0.1);
}
.nav-item {
  font-size: 12px;
  color: #9fa3a6;
  transition: all 0.3s ease;
  line-height: 24px;
  display: inline-block;
  vertical-align: baseline;
  text-decoration: none;
}
.img {
  width: 16px;
  height: 16px;
}
.footer-bottom {
  color: #6c7073;
  font-size: 12px;
  justify-content: space-between;
  align-items: center;
  display: flex;
  font-size: 12px;
  color: #6c7073;
  transition: all 0.3s ease;
  padding: 16px 0 0;
}
.footer-legal {
  line-height: 24px;
  display: flex;
  align-items: center;
}
.legal-links {
  line-height: 24px;
  display: inline-block;
  font-size: 12px;
  color: #6c7073;
  padding: 0;
  margin-right: 10px;
}
.footer-desc {
  color: #616466;
  font-size: 12px;
  display: flex;
  align-items: center;
  justify-content: left;
  margin-top: 8px;
}
.copyright {
  font-size: 12px;
  color: #6c7073;
  padding-right: 16px;
}
.footerdesc-cnF {
  color: #616466;
  font-size: 12px;
  display: flex;
  align-items: center;
  justify-content: left;
}
#footer-record {
  margin: 0;
  padding: 0;
  border: 0;
  font-size: 100%;
  font-weight: 400;
  vertical-align: baseline;
  background: transparent;
}
.ad-desc {
  color: #616466;
  font-size: 12px;
}
.ad-descc {
  color: #616466;
  font-size: 12px;
  padding-right: 16px;
}
</style>