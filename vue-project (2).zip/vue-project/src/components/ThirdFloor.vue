<template>
  <div class="box1">
    <div class="center1">
      <div class="title">
        <h2>怎么飞，安全都是第一</h2>
        <p>
          DJI Mini 3 Pro
          的避障和图传系统迎来全方位革新，可轻松实现灵活绕障和稳定的影像传输，各项安全性能组合发力，实力不容小觑。
        </p>
      </div>
      <div class="content1">
        <h3>三向避障，多面探测</h3>
        <p>
          配备前视、后视、下视双目视觉感应系统和
          ToF，同时得益于全新的机身设计，障碍物感应范围进一步增大，共同打造了
          DJI Mini 系列迄今安全性最强的无人机。安全高标准，飞行少担忧。
        </p>
      </div>
      <div class="video1">
        <video 
        id="video5"
          
          muted>
          <source
            src="/indexMp4/5.mp4"
          />
        </video>
      </div>
      <div class="content2">
        <h3>别忘了，还有 APAS 4.0</h3>
        <p>
          APAS
          4.0（飞行辅助系统）<sup>[4]</sup>可实时探测飞行路径上的物体，即使身处复杂环境，DJI
          Mini 3 Pro 也能灵活躲避障碍物，飞行过程中安全守护不间断。
        </p>
      </div>
      <div class="video2">
        <video 
        id="video6"
          
          muted>
          <source
            src="/indexMp4/6.mp4"
          />
        </video>
      </div>
      <div class="content3">
        <div class="content3-1">
          <div class="content3-1-left">
            <h3>O3 图传“护体”，稳住大场面</h3>
          </div>
          <div class="content3-1-right">
            <p>
              采用 DJI O3 旗舰型数字图传，1080p/30fps 最高实时图传画质和 12
              公里<sup>[5]</sup>最远传输距离，一并奉上。无论是拍摄城市景观，还是在野外探索，都能飞得稳，看得清。
            </p>
          </div>
        </div>
        <div class="content3-pic">
          <img
            src="/indexImg/5.jpg"
            alt=""
          />
        </div>
        <div class="content3-2">
          <p>
            无论是 RC-N1 遥控器还是全新带屏遥控器 DJI RC，均可通过 O3 图传实现
            18Mbps 最大图传码率和 120
            毫秒超低图传延时，操控反馈迅速，其流畅度与灵敏度，都超乎想象。
          </p>
        </div>
      </div>
      <div class="content4">
        <h2>易拍，趣拍，分享快一拍</h2>
        <p>
          还有各项智能功能齐聚于 DJI Mini 3
          Pro，带来丰富的视觉效果和多样玩法，让你不费吹灰之力拍大作，畅享航拍乐趣。
        </p>
      </div>
      <div class="content4-1">
        <div class="content4-1-left">
          <div class="content4-1-left-top">
            <h3>无损竖拍</h3>
          </div>
          <div class="content4-1-left-footer">
            <video id="video8"  muted>
              <source
                src="/indexMp4/8.mp4"
              />
            </video>
          </div>
        </div>
        <div class="content4-1-right">
          <div class="content4-1-right-top">
            <video id="video9"  muted>
              <source
                src="/indexMp4/9.mp4"
              />
            </video>
          </div>
          <div class="content4-1-right-footer">
            <p>
              采用全新云台构型设计，云台转动限位更小，支持无裁切竖拍，画质不妥协，引领竖版航拍视频潮流。
            </p>
          </div>
        </div>
      </div>
      <div class="video3">
        <video 
        id="video10"
        
          muted>
          <source
            src="/indexMp4/10.mp4"
          />
        </video>
      </div>
      <div class="content4-footer-1">
        <div class="content4-footer-1-box">
          <div class="content4-footer-1-box-line"></div>
          <div class="content4-footer-1-box-text">
            <div class="content4-footer-1-box-text-1">
              <div>大师镜头</div>
            </div>
            <div class="content4-footer-1-box-text-2">
              <div>焦点跟随</div>
            </div>
            <div class="content4-footer-1-box-text-3">
              <div>延迟摄影</div>
            </div>
            <div class="content4-footer-1-box-text-4">
              <div>数码变焦</div>
            </div>
          </div>
        </div>
      </div>
      <div class="content4-footer-2">
        <div class="content4-footer-2-text-1">
          <div class="content4-footer-2-text-1-content">
            一键启用后，飞行器自动拍摄多条具有专业运镜水准的短片，并完成剪辑和配乐，惬意之间，
            <br />
            大片到手。
          </div>
        </div>
        <div class="content4-footer-2-text-2">
          <div class="content4-footer-2-text-2-content">
            配备智能跟随、聚焦、兴趣点环绕三种跟拍模式，将主角始终锁定在 C 位。
          </div>
        </div>
        <div class="content4-footer-2-text-3">
          <div class="content4-footer-2-text-3-content">
            轻点几下屏幕，只需静候片刻，时光流转，云卷云舒，都浓缩在高画质延时影片中。
          </div>
        </div>
        <div class="content4-footer-2-text-4">
          <div class="content4-footer-2-text-4-content">
            录制 1080p 解析度影片时，最高可选择 4
            倍数码变焦，远近焦段随心切换，构图灵活自如，激发更多创作巧思。
          </div>
        </div>
      </div>
      <div class="content5">
        <div class="content5-1">
          <h3>手机快传</h3>
        </div>
        <div class="content5-2">
          <p>支持 Wi-Fi 高速下载，最高速率可达 25MB/s，即拍即传，效率当先。</p>
        </div>
        <div class="content5-3">
          <img
            src="/indexImg/4.jpg"
            alt=""
          />
        </div>
      </div>
    </div>
    <div class="content6">
      <div class="content6-1">
        <div class="content6-1-text">
          <h2>配件，航拍实力助攻</h2>
          <p>
            将这些实用配件收入囊中，为影像创作加持。从容飞行，航拍时更能大显身手。
          </p>
        </div>
      </div>
    </div>
    <div class="center2">
      <div class="content7">
        <div class="content7-left">
          <ul>
            <li :class="{imgActive:n==1}" class="changeL">
              <img
                src="/indexImg/7.jpg"
                alt=""
              />
              <div>
                <h5>DJI Mini 3 Pro 长续航智能飞行电池<sup>[7]</sup></h5>
                <p>
                  最长续航时间 47
                  分钟<sup>[2]</sup>，提供充裕的取景和构图空间，让你告别续航焦虑，尽兴飞行，满载而归。
                </p>
              </div>
            </li>
             <li :class="{imgActive:n==3}"  class="changeL">
              <img
                src="/indexImg/2.png"
                alt=""
              />
              <div>
                <h5>双向充电管家<sup>[7]</sup></h5>
                <p>
                  可同时为遥控器和三块电池依次充电，也可充当移动电源给遥控器或手机等设备充电，还能收纳电池，方便携带。
                </p>
              </div>
            </li>
            <li :class="{imgActive:n==2}"  class="changeL">
              <img
                src="/indexImg/3.png"
                alt=""
              />
              <div>
                <h5>ND 镜套装<sup>[7]</sup></h5>
                <p>提供 ND16/64/256 减光滤镜套装，应对日间强光拍摄环境。</p>
              </div>
            </li>
            <li :class="{imgActive:n==4}"  class="changeL">
              <img
                src="/indexImg/4.png"
                alt=""
              />
              <div>
                <h5>DJI RC<sup>[7]</sup></h5>
                <p>
                  专为 DJI Mini 3 Pro 打造的轻量化带屏遥控器，内置 DJI Fly
                  app，操作便捷高效。航拍不会因手机来电等通知而中断，让你专注创作，享受飞行乐趣，也为手机节省更多电量。
                </p>
              </div>
            </li>  
          </ul>
        </div>
        <div class="content7-right">
          <div class="content7-right-1">
            <div class="content7-right-1-top" :class="{boxActive:n==1}">
              <h5>DJI Mini 3 Pro 长续航智能飞行电池<sup>[7]</sup></h5>
              <div class="content7-right-1-top-img">
                <img
                  src="/indexImg/1.png"
                  alt=""
                  @click="n=1"
                  :class="{boxActive:n==1}"
                />
              </div>
            </div>
            <div class="content7-right-1-bottom" :class="{boxActive:n==2}">
              <h5>ND 镜套装<sup>[7]</sup></h5>
              <div class="content7-right-1-bottom-img">
                <img
               
                  @click="n=2"
                  src="/indexImg/3.png"
                  alt=""
                />
              </div>
            </div>
          </div>
          <div class="content7-right-2">
            <div class="content7-right-2-top"  :class="{boxActive:n==3}">
              <h5>双向充电管家<sup>[7]</sup></h5>
              <div class="content7-right-2-top-img">
                <img
               
                  @click="n=3"
                  src="/indexImg/2.png"
                  alt=""
                />
              </div>
            </div>
            <div class="content7-right-2-bottom" :class="{boxActive:n==4}">
              <h5>DJI RC<sup>[7]</sup></h5>
              <div class="content7-right-2-bottom-img">
                <img
                
                  @click="n=4"
                  src="/indexImg/4.png"
                  alt=""
                />
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="content8">
        <div class="content8-1">
          <div class="content8-1-all">
            <img
              class="content8-1-all-img1"
              src="/indexImg/12.jpg"
              alt=""
            />
            <div class="content8-1-all-product_name">
              <div class="content8-1-all-top-product_name-img">
                <img
                  class="content8-1-all-img2"
                  src="/indexImg/logo.svg"
                  alt=""
                />
              </div>
              <p>小有成就</p>
            </div>
            <div class="content8-1-all-product_price">
              <span class="content8-1-all-product_price-1">¥4788</span>
              <span class="content8-1-all-product_price-2">&nbsp;起</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  data() {
    return {
      n: 1,
      
    }
  },
  
   mounted() {
    //给窗口添加鼠标滚动监听事假
    window.addEventListener("scroll", this.menu);
  },

  methods: {
    menu() {
      this.scroll = document.documentElement.scrollTop;
      //打印滚动距离
      //console.log(this.scroll)

      //video8和vidoe9同时播放
      if(this.scroll>11800 && this.scroll<13800 ){

         video8.setAttribute("autoplay", "autoplay");
      //给视频标签添加循环播放---video标签属性。
      video8.setAttribute("loop", "loop");
      //播放视频
      video8.play();
      //console.log("8开始播放...");

      
         video9.setAttribute("autoplay", "autoplay");
      //给视频标签添加循环播放---video标签属性。
      video9.setAttribute("loop", "loop");
      //播放视频
      video9.play();
      //console.log("9开始播放...");
      }

      //video10的播放
       if(this.scroll>13000 && this.scroll<14300 ){

         video10.setAttribute("autoplay", "autoplay");
      //给视频标签添加循环播放---video标签属性。
      video10.setAttribute("loop", "loop");
      //播放视频
      video10.play();
      //console.log("10开始播放...");
    }


    //视频video6的播放
    if(this.scroll>9688 && this.scroll<11088 ){

         video6.setAttribute("autoplay", "autoplay");
      //给视频标签添加循环播放---video标签属性。
      video6.setAttribute("loop", "loop");
      //播放视频
      video6.play();
      //console.log("6开始播放...");
    }

     //视频video5的播放
    if(this.scroll>8447 && this.scroll<10047 ){

         video5.setAttribute("autoplay", "autoplay");
      //给视频标签添加循环播放---video标签属性。
      video5.setAttribute("loop", "loop");
      //播放视频
      video5.play();
      //console.log("5开始播放...");
    }
    },
   
   
  },
  
};
</script>
<style  scoped>
.changeL{
  display: none;
 
}
.imgActive{
  display: block;
 
}
.boxActive{
  background-color: #f0f1f2!important;
}
* {
  margin: 0;
  padding: 0;
}
.box1 {
  background-color: #fff;
}
.center1 {
  width: 1200px;
  margin: 0 auto;
}
.title {
  margin-top: 128px;
  text-align: center;
}
.title h2 {
  color: rgba(0, 0, 0, 0.85);
  max-width: 795px;
  font-size: 48px;
  line-height: 52px;
  letter-spacing: -0.03em;
  margin: 0 auto;
}
.title p {
  color: rgba(0, 0, 0, 0.65);
  max-width: 795px;
  font-size: 20px;
  line-height: 28px;
  letter-spacing: -0.03em;
  margin-top: 24px;
  margin: 0 auto;
}
.content1 {
  padding-top: 128px;
}
.content1 h3 {
  color: rgba(0, 0, 0, 0.85);
  max-width: 693px;
  font-size: 40px;
  line-height: 48px;
  letter-spacing: -0.03em;
}
.content1 p {
  color: rgba(0, 0, 0, 0.65);
  max-width: 845px;
  font-size: 18px;
  line-height: 28px;
  letter-spacing: -0.03em;
  margin-top: 24px;
}
.video1 {
  margin-top: 48px;
  border-radius: 16px;
  overflow: hidden;
}
.content2 {
  padding-top: 128px;
}
.content2 h3 {
  color: rgba(0, 0, 0, 0.85);
  max-width: 693px;
  font-size: 40px;
  line-height: 48px;
  letter-spacing: -0.03em;
}
.content2 p {
  color: rgba(0, 0, 0, 0.65);
  max-width: 845px;
  font-size: 18px;
  line-height: 28px;
  letter-spacing: -0.03em;
  margin-top: 24px;
}
.video2 {
  margin-top: 48px;
  border-radius: 16px;
  overflow: hidden;
}
.content3 {
  padding-top: 128px;
}
.content3-1 {
  width: 100%;
  display: flex;
  flex-wrap: nowrap;
  align-items: flex-start;
}
.content3-1-left h3 {
  color: rgba(0, 0, 0, 0.85);
  max-width: 593px;
  font-size: 40px;
  line-height: 48px;
  letter-spacing: -0.1em;
}
.content3-1-right p {
  color: rgba(0, 0, 0, 0.65);
  max-width: 593px;
  font-size: 18px;
  line-height: 28px;
  letter-spacing: -0.03em;
  margin-left: 16px;
  padding-left: 100px;
  padding-bottom: 8px;
}
.content3-pic {
  margin-bottom: 48px;
  border-radius: 16px;
  overflow: hidden;
  padding-top: 48px;
}
.content3-pic img {
  display: block;
  width: 100%;
  height: auto;
}
.content3-2 p {
  color: rgba(0, 0, 0, 0.65);
  max-width: 795px;
  font-size: 18px;
  line-height: 28px;
  letter-spacing: -0.03em;
  padding-bottom: 128px;
}
.content4 {
  margin-top: 128px;
  text-align: center;
}
.content4 h2 {
  color: rgba(0, 0, 0, 0.85);
  max-width: 795px;
  font-size: 48px;
  line-height: 52px;
  letter-spacing: -0.03em;
  margin: 0 auto;
}
.content4 p {
  color: rgba(0, 0, 0, 0.65);
  max-width: 795px;
  font-size: 20px;
  line-height: 28px;
  letter-spacing: -0.03em;
  padding-top: 24px;
  margin: 0 auto;
}
.content4-1 {
  padding-top: 128px;
  display: flex;
  width: 1200px;
}
.content4-1-left {
  /* padding: 0px 56px 4px 128px; */
  outline: none;
}
.content4-1-left-top h3 {
  color: rgba(0, 0, 0, 0.85);
  max-width: 693px;
  font-size: 40px;
  line-height: 48px;
  letter-spacing: -0.03em;
}
.content4-1-left-footer video {
  margin-top: 48px;
  border-radius: 16px;
  overflow: hidden;
  width: 600px;
  height: 1066px;
}
.content4-1-right {
  margin-left: 16px;
}
.content4-1-right-top video {
  border-radius: 16px;
  overflow: hidden;
  width: 600px;
  height: 1066px;
}
.content4-1-right-footer p {
  color: rgba(0, 0, 0, 0.65);
  max-width: 693px;
  font-size: 18px;
  line-height: 28px;
  letter-spacing: -0.03em;
  padding-top: 24px;
}
.video3 video {
  width: 100%;
  border-radius: 16px;
  padding-top: 128px;
}
.ontent4-footer-1 {
  margin: 0 auto;
  display: inline-block;
  position: relative;
  color: rgba(0, 0, 0, 0.45);
  border-bottom: 1px solid rgba(0, 0, 0, 0.09);
}
.content4-footer-1-box {
  display: inline-block;
}
.content4-footer-1-box-line {
  width: 94px;
  transform: translate3d(0px, 0px, 0px);
  background: rgba(0, 0, 0, 0.85);
}
.content4-footer-1-box-text {
  display: inline-block;
}
.content4-footer-1-box-text-1 {
  margin-right: 48px;
  transition: all 0.3s ease;
  display: inline-block;
}
.content4-footer-1-box-text-2 {
  margin-right: 48px;
  transition: all 0.3s ease;
  display: inline-block;
}
.content4-footer-1-box-text-3 {
  margin-right: 48px;
  transition: all 0.3s ease;
  display: inline-block;
}
.content4-footer-1-box-text-4 {
  margin-right: 48px;
  transition: all 0.3s ease;
  display: inline-block;
}
.content4-footer-2 {
  display: flex;
  flex-wrap: wrap;
  width: 100%;
  justify-content: center;
  min-height: 128px;
}
.content4-footer-2-text-1 {
  color: rgba(0, 0, 0, 0.85);
}
.content4-footer-2-text-1-content {
  padding-top: 32px;
}
.content4-footer-2-text-2 {
  color: rgba(0, 0, 0, 0.85);
}
.content4-footer-2-text-2-content {
  padding-top: 32px;
}
.content4-footer-2-text-3 {
  color: rgba(0, 0, 0, 0.85);
}
.content4-footer-2-text-3-content {
  padding-top: 32px;
}
.content4-footer-2-text-4 {
  color: rgba(0, 0, 0, 0.85);
}
.content4-footer-2-text-4-content {
  padding-top: 32px;
}
.content5 {
  padding-top: 96px;
  padding-bottom: 128px;
  width: 1200px;
}
.content5-1 h3 {
  color: rgba(0, 0, 0, 0.85);
  max-width: 693px;
  font-size: 40px;
  line-height: 48px;
  letter-spacing: -0.03em;
}
.content5-2 p {
  color: rgba(0, 0, 0, 0.65);
  max-width: 793px;
  font-size: 18px;
  line-height: 28px;
  letter-spacing: -0.03em;
  margin-top: 24px;
}
.content5-3 {
  margin-top: 48px;
  border-radius: 16px;
  overflow: hidden;
}
.content5-3 img {
  display: block;
  width: 100%;
  height: auto;
}
.content6 {
  background-image: url("@/assets/index/6.jpg");
  width: 100%;
  height: 850px;
  background-size: cover;
  background-position: center center;
  background-repeat: no-repeat;
  background-attachment: scroll;
  overflow: hidden;
  box-sizing: border-box;
}
.content6-1 {
  position: relative;
}
.content6-1-text {
  text-align: center;
  position: absolute;
  top: 96px;
  left: 50%;
  transform: translateX(-50%);
}
.content6-1-text h2 {
  color: rgba(0, 0, 0, 0.85);
  max-width: 693px;
  font-size: 48px;
  line-height: 52px;
  letter-spacing: -0.03em;
  margin: 0 auto;
  display: inline-block;
}
.content6-1-text p {
  color: rgba(0, 0, 0, 0.65);
  max-width: 693px;
  font-size: 20px;
  line-height: 28px;
  letter-spacing: -0.03em;
  margin: 24px auto 0 auto;
}
.center2 {
  width: 1200px;
  margin: 0 auto;
}
.content7 {
  display: flex;
  padding-bottom: 128px;
}
.content7-left {
  margin-top: 96px;
}
.content7-left img {
  width: 496px;
  height: 496px;
  display: block;
  border: 0;
}
ul {
  list-style: none;
  margin-right: 50px;
}
li div h5 {
  font-size: 18px;
  letter-spacing: -0.03em;
  line-height: 24px;
  color: rgba(0, 0, 0, 0.65);
  max-width: 413px;
}
li div p {
  font-size: 14px;
  letter-spacing: -0.02em;
  line-height: 20px;
  margin-top: 8px;
  color: rgba(0, 0, 0, 0.65);
  max-width: 413px;
}
.content7-right {
  width: 592px;
  margin-top: 96px;
  display: flex;
  justify-content: space-between;
  margin-left: 50px;
}
.content7-right-1 {
  width: 292px;
  margin-right: 10px;
}
.content7-right-1-top {
  height: 260px;
  padding-top: 52px;
  border-radius: 16px;
  width: 100%;
  position: relative;
  overflow: hidden;
  background: #fff;
  margin-bottom: 8px;
}
.content7-right-1-top h5 {
  font-size: 14px;
  letter-spacing: -0.02em;
  line-height: 20px;
  color: rgba(0, 0, 0, 0.65);
  position: absolute;
  top: 16px;
  left: 16px;
  right: 16px;
}
.content7-right-1-top-img {
  overflow: hidden;
  text-align: center;
  margin-top: 5px;
}
.content7-right-1-top-img img {
  width: 160px;
  margin: 0 auto;
  height: 100%;
  position: relative;
}
.content7-right-1-bottom {
  height: 260px;
  padding-top: 52px;
  border-radius: 16px;
  width: 100%;
  position: relative;
  overflow: hidden;
  background: #fff;
  margin-bottom: 8px;
}
.content7-right-1-bottom h5 {
  font-size: 14px;
  letter-spacing: -0.02em;
  line-height: 20px;
  color: rgba(0, 0, 0, 0.65);
  position: absolute;
  top: 16px;
  left: 16px;
  right: 16px;
}
.content7-right-1-bottom-img {
  overflow: hidden;
  text-align: center;
  margin-top: 5px;
}
.content7-right-1-bottom-img img {
  width: 160px;
  margin: 0 auto;
  height: 100%;
  position: relative;
}
.content7-right-2 {
  width: 292px;
}
.content7-right-2-top {
  height: 260px;
  padding-top: 52px;
  border-radius: 16px;
  width: 100%;
  position: relative;
  overflow: hidden;
  background: #fff;
  margin-bottom: 8px;
}
.content7-right-2-top h5 {
  font-size: 14px;
  letter-spacing: -0.02em;
  line-height: 20px;
  color: rgba(0, 0, 0, 0.65);
  position: absolute;
  top: 16px;
  left: 16px;
  right: 16px;
}
.content7-right-2-top-img {
  overflow: hidden;
  text-align: center;
  margin-top: 5px;
}
.content7-right-2-top-img img {
  width: 160px;
  margin: 0 auto;
  height: 100%;
  position: relative;
}
.content7-right-2-bottom {
  height: 260px;
  padding-top: 52px;
  border-radius: 16px;
  width: 100%;
  position: relative;
  overflow: hidden;
  background: #fff;
  margin-bottom: 8px;
}
.content7-right-2-bottom h5 {
  font-size: 14px;
  letter-spacing: -0.02em;
  line-height: 20px;
  color: rgba(0, 0, 0, 0.65);
  position: absolute;
  top: 16px;
  left: 16px;
  right: 16px;
}
.content7-right-2-bottom-img {
  overflow: hidden;
  text-align: center;
  margin-top: 5px;
}
.content7-right-2-bottom-img img {
  width: 160px;
  margin: 0 auto;
  height: 100%;
  position: relative;
}
.content8 {
  padding: 0 0 128px;
}
.content8-1 {
  width: 1200px !important;
  position: relative;
  margin-right: auto;
  margin-left: auto;
  cursor: pointer;
  padding: 0;
}
.content8-1-all {
  height: 400px;
  padding-top: 0;
  text-align: left;
  position: relative;
  min-height: 300px;
}
.content8-1-all-img1 {
  width: 100%;
  display: block;
}
.content8-1-all-product_name {
  position: absolute;
  top: 110px;
  left: 96px;
}
.content8-1-all-product_name-img {
  text-align: left;
  margin-bottom: 16px;
}
.content8-1-all-img2 {
  width: 294px;
  height: 32px;
}
.content8-1-all-product_name p {
  color: black;
  font-weight: bold;
  font-size: 20px;
  letter-spacing: -0.6px;
  line-height: 24px;
  margin-top: 16px;
}
.content8-1-all-product_price {
  position: absolute;
  left: 96px;
  bottom: 166px;
}
.content8-1-all-product_price-1 {
  vertical-align: baseline;
  font-weight: 400;
  color: black;
  font-size: 24px;
  line-height: 28px;
  letter-spacing: -0.03em;
  text-align: left;
}
.content8-1-all-product_price-2 {
  margin-left: 4px;
  font-weight: 400;
  font-size: 16px;
  color: black;
  letter-spacing: -0.02em;
  line-height: 20px;
}
</style>
<style lang="scss" scoped>
</style>